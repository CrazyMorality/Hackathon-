const mongoose = require("mongoose");

mongoose.connect("mongodb://localhost:27017/LoginSignUpTutorial")
    .then(() => {
        console.log("mongodb connected");
    })
    .catch(() => {
        console.log("failed to connect");
    });

const LogInSchema1 = new mongoose.Schema({
    Enter_full_name: {
        type: String,
        required: true
    },
    Enter_contact_number: {
        type: String,
        required: true
    },
    Enter_street_address: {
        type: String,
        required: true
    },
    Enter_your_state: {
        type: String,
        required: true
    },
    Enter_account_number: {
        type: String,
        required: true
    },
    Enter_IFSC_code: {
        type: String,
        required: true
    },
    Enter_salary: {
        type: String,
        required: true
    },
    Enter_loan_amount: {
        type: String,
        required: true
    },
    Enter_duration: {
        type: String,
        required: true
    }
});

// Check if the model already exists before defining it
const Collection1 = mongoose.models.Collection1 || mongoose.model("Collection1", LogInSchema1);

module.exports = Collection1;

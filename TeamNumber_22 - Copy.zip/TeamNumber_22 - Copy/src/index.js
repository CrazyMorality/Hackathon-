const express = require("express");
const path = require("path");
const app = express();
const hbs = require("hbs");
const Collections=require("./mongodb")
const Collection1=require("./mongodb1")

const tempelatePath = path.join(__dirname, '../tempelates')

app.use(express.json())
app.set('view engine', 'hbs')
app.set('views', tempelatePath)
app.use(express.urlencoded({ extended: false }))

// app.get("/", (req, res) => {
//     res.render("start");
// });

app.get("/", (req, res) => {
    res.render("login");
});

app.get("/signup", (req, res) => {
    res.render("signup");
});

app.post("/signup", async (req, res) => {
    const data = {
        name: req.body.name,
        email: req.body.email,
        PhoneNumber: req.body.PhoneNumber,
        password: req.body.password,
        confirm_password: req.body.confirm_password,
    };

    await Collections.insertMany([data]);
    console.log("submitted successfully!")
    res.render("home");
});

app.get("/home", (req, res) => {
    res.render("home");
});

app.post("/home", async (req, res) => {
    const data1 = {
        Enter_full_name: req.body.Enter_full_name,
        Enter_contact_number: req.body.Enter_contact_number,
        Enter_street_address: req.body.Enter_street_address,
        Enter_your_state: req.body.Enter_your_state,
        Enter_account_number: req.body.Enter_account_number,
        Enter_IFSC_code: req.body.Enter_IFSC_code,
        Enter_salary: req.body.Enter_salary,
        Enter_loan_amount: req.body.Enter_loan_amount,
        Enter_duration: req.body.Enter_duration,
    };

    await Collection1.insertMany([data1]);
    res.render("last");
});

app.post("/login", async (req, res) => {
    try {
        const check = await Collections.findOne({ name: req.body.name });

        if (check.password === req.body.password) {
            res.render("home");
        } else {
            res.send("wrong password");
        }

    } catch {
        res.send("wrong details");
    }
});

app.listen(3000, () => {
    console.log("port connected");
});
